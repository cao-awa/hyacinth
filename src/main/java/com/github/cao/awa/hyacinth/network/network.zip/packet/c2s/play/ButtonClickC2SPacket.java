package com.github.cao.awa.hyacinth.network.packet.c2s.play;

import com.github.cao.awa.hyacinth.network.packet.Packet;
import com.github.cao.awa.hyacinth.network.packet.buf.PacketByteBuf;
import com.github.cao.awa.hyacinth.network.packet.listener.ServerPlayPacketListener;

public class ButtonClickC2SPacket
implements Packet<ServerPlayPacketListener> {
    private final int syncId;
    private final int buttonId;

    public ButtonClickC2SPacket(int syncId, int buttonId) {
        this.syncId = syncId;
        this.buttonId = buttonId;
    }

    @Override
    public void apply(ServerPlayPacketListener serverPlayPacketListener) {
        serverPlayPacketListener.onButtonClick(this);
    }

    public ButtonClickC2SPacket(PacketByteBuf buf) {
        this.syncId = buf.readByte();
        this.buttonId = buf.readByte();
    }

    @Override
    public void write(PacketByteBuf buf) {
        buf.writeByte(this.syncId);
        buf.writeByte(this.buttonId);
    }

    public int getSyncId() {
        return this.syncId;
    }

    public int getButtonId() {
        return this.buttonId;
    }
}

