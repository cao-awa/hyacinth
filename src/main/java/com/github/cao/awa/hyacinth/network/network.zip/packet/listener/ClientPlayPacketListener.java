package com.github.cao.awa.hyacinth.network.packet.listener;

import com.github.cao.awa.hyacinth.network.packet.s2c.play.*;

/**
 * A client side packet listener where play stage packets from the server are processed.
 */
public interface ClientPlayPacketListener
extends PacketListener {
    /**
     * Handles the spawning of non-living entities.
     */
    void onEntitySpawn(EntitySpawnS2CPacket var1);

    void onExperienceOrbSpawn(ExperienceOrbSpawnS2CPacket var1);

    void onVibration(VibrationS2CPacket var1);

    void onMobSpawn(MobSpawnS2CPacket var1);

    void onScoreboardObjectiveUpdate(ScoreboardObjectiveUpdateS2CPacket var1);

    void onPaintingSpawn(PaintingSpawnS2CPacket var1);

    void onPlayerSpawn(PlayerSpawnS2CPacket var1);

    void onEntityAnimation(EntityAnimationS2CPacket var1);

    void onStatistics(StatisticsS2CPacket var1);

    void onUnlockRecipes(UnlockRecipesS2CPacket var1);

    void onBlockBreakingProgress(BlockBreakingProgressS2CPacket var1);

    void onSignEditorOpen(SignEditorOpenS2CPacket var1);

    void onBlockEntityUpdate(BlockEntityUpdateS2CPacket var1);

    void onBlockEvent(BlockEventS2CPacket var1);

    void onBlockUpdate(BlockUpdateS2CPacket var1);

    void onGameMessage(GameMessageS2CPacket var1);

    void onChunkDeltaUpdate(ChunkDeltaUpdateS2CPacket var1);

    void onMapUpdate(MapUpdateS2CPacket var1);

    void onCloseScreen(CloseScreenS2CPacket var1);

    void onInventory(InventoryS2CPacket var1);

    void onOpenHorseScreen(OpenHorseScreenS2CPacket var1);

    void onScreenHandlerPropertyUpdate(ScreenHandlerPropertyUpdateS2CPacket var1);

    void onScreenHandlerSlotUpdate(ScreenHandlerSlotUpdateS2CPacket var1);

    void onCustomPayload(CustomPayloadS2CPacket var1);

    void onDisconnect(DisconnectS2CPacket var1);

    void onEntityStatus(EntityStatusS2CPacket var1);

    void onEntityAttach(EntityAttachS2CPacket var1);

    void onEntityPassengersSet(EntityPassengersSetS2CPacket var1);

    void onExplosion(ExplosionS2CPacket var1);

    void onGameStateChange(GameStateChangeS2CPacket var1);

    void onKeepAlive(KeepAliveS2CPacket var1);

    void onChunkData(ChunkDataS2CPacket var1);

    void onUnloadChunk(UnloadChunkS2CPacket var1);

    void onWorldEvent(WorldEventS2CPacket var1);

    void onGameJoin(GameJoinS2CPacket var1);

    void onEntity(EntityS2CPacket var1);

    void onPlayerPositionLook(PlayerPositionLookS2CPacket var1);

    void onParticle(ParticleS2CPacket var1);

    void onPing(PlayPingS2CPacket var1);

    void onPlayerAbilities(PlayerAbilitiesS2CPacket var1);

    void onPlayerList(PlayerListS2CPacket var1);

    void onEntitiesDestroy(EntitiesDestroyS2CPacket var1);

    void onRemoveEntityStatusEffect(RemoveEntityStatusEffectS2CPacket var1);

    void onPlayerRespawn(PlayerRespawnS2CPacket var1);

    void onEntitySetHeadYaw(EntitySetHeadYawS2CPacket var1);

    void onUpdateSelectedSlot(UpdateSelectedSlotS2CPacket var1);

    void onScoreboardDisplay(ScoreboardDisplayS2CPacket var1);

    void onEntityTrackerUpdate(EntityTrackerUpdateS2CPacket var1);

    void onEntityVelocityUpdate(EntityVelocityUpdateS2CPacket var1);

    void onEntityEquipmentUpdate(EntityEquipmentUpdateS2CPacket var1);

    void onExperienceBarUpdate(ExperienceBarUpdateS2CPacket var1);

    void onHealthUpdate(HealthUpdateS2CPacket var1);

    void onTeam(TeamS2CPacket var1);

    void onScoreboardPlayerUpdate(ScoreboardPlayerUpdateS2CPacket var1);

    void onPlayerSpawnPosition(PlayerSpawnPositionS2CPacket var1);

    void onWorldTimeUpdate(WorldTimeUpdateS2CPacket var1);

    void onPlaySound(PlaySoundS2CPacket var1);

    void onPlaySoundFromEntity(PlaySoundFromEntityS2CPacket var1);

    void onPlaySoundId(PlaySoundIdS2CPacket var1);

    void onItemPickupAnimation(ItemPickupAnimationS2CPacket var1);

    void onEntityPosition(EntityPositionS2CPacket var1);

    void onEntityAttributes(EntityAttributesS2CPacket var1);

    void onEntityStatusEffect(EntityStatusEffectS2CPacket var1);

    void onSynchronizeTags(SynchronizeTagsS2CPacket var1);

    void onEndCombat(EndCombatS2CPacket var1);

    void onEnterCombat(EnterCombatS2CPacket var1);

    void onDeathMessage(DeathMessageS2CPacket var1);

    void onDifficulty(DifficultyS2CPacket var1);

    void onSetCameraEntity(SetCameraEntityS2CPacket var1);

    void onWorldBorderInitialize(WorldBorderInitializeS2CPacket var1);

    void onWorldBorderInterpolateSize(WorldBorderInterpolateSizeS2CPacket var1);

    void onWorldBorderSizeChanged(WorldBorderSizeChangedS2CPacket var1);

    void onWorldBorderWarningTimeChanged(WorldBorderWarningTimeChangedS2CPacket var1);

    void onWorldBorderWarningBlocksChanged(WorldBorderWarningBlocksChangedS2CPacket var1);

    void onWorldBorderCenterChanged(WorldBorderCenterChangedS2CPacket var1);

    void onPlayerListHeader(PlayerListHeaderS2CPacket var1);

    void onResourcePackSend(ResourcePackSendS2CPacket var1);

    void onBossBar(BossBarS2CPacket var1);

    void onCooldownUpdate(CooldownUpdateS2CPacket var1);

    void onVehicleMove(VehicleMoveS2CPacket var1);

    void onAdvancements(AdvancementUpdateS2CPacket var1);

    void onSelectAdvancementTab(SelectAdvancementTabS2CPacket var1);

    void onCraftFailedResponse(CraftFailedResponseS2CPacket var1);

    void onCommandTree(CommandTreeS2CPacket var1);

    void onStopSound(StopSoundS2CPacket var1);

    void onCommandSuggestions(CommandSuggestionsS2CPacket var1);

    void onSynchronizeRecipes(SynchronizeRecipesS2CPacket var1);

    void onLookAt(LookAtS2CPacket var1);

    void onNbtQueryResponse(NbtQueryResponseS2CPacket var1);

    void onLightUpdate(LightUpdateS2CPacket var1);

    void onOpenWrittenBook(OpenWrittenBookS2CPacket var1);

    void onOpenScreen(OpenScreenS2CPacket var1);

    void onSetTradeOffers(SetTradeOffersS2CPacket var1);

    void onChunkLoadDistance(ChunkLoadDistanceS2CPacket var1);

    void onSimulationDistance(SimulationDistanceS2CPacket var1);

    void onChunkRenderDistanceCenter(ChunkRenderDistanceCenterS2CPacket var1);

    void onPlayerActionResponse(PlayerActionResponseS2CPacket var1);

    void onOverlayMessage(OverlayMessageS2CPacket var1);

    void onSubtitle(SubtitleS2CPacket var1);

    void onTitle(TitleS2CPacket var1);

    void onTitleFade(TitleFadeS2CPacket var1);

    void onTitleClear(ClearTitleS2CPacket var1);
}

