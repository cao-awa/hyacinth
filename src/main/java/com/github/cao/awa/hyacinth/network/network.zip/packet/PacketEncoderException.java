package com.github.cao.awa.hyacinth.network.packet;

import io.netty.handler.codec.EncoderException;

public class PacketEncoderException
        extends EncoderException {
    public PacketEncoderException(Throwable cause) {
        super(cause);
    }
}

