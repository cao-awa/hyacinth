package com.github.cao.awa.hyacinth.network.packet.listener;

import com.github.cao.awa.hyacinth.network.packet.c2s.query.QueryPingC2SPacket;
import com.github.cao.awa.hyacinth.network.packet.c2s.query.QueryRequestC2SPacket;

public interface ServerQueryPacketListener
extends PacketListener {
    void onPing(QueryPingC2SPacket var1);

    void onRequest(QueryRequestC2SPacket var1);
}

